<ul class="nav nav-tabs nav-bordered mb-3">
    <li class="nav-item">
        <a href="/absensi-pegawai" class="nav-link ">
            Absensi
        </a>
    </li>
    <li class="nav-item">
        <a href="/rekap-absen" class="nav-link ">
            Rekap
        </a>
    </li>
</ul> <!-- end nav-->